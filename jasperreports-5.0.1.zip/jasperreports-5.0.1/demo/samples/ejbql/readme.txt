You need Java 1.5 to run this sample.

You need to have the ANT build tool correctly installed on your system
to easily run this sample application. This tool can be downloaded from 
this location: http://ant.apache.org/
Please follow their installing instructions to have ANT working on your
system before trying our sample application.

Once you have ANT installed, launch "ant -p" from the command line in this directory
to learn more about what tasks you could run to build and test the sample.
